
# Abigail Estavillo - Virtual Assistant Portfolio

This is the HTML/CSS version of Abigail Estavillo's portfolio website. It showcases her experience, services, testimonials, and contact information.

## Pages Included
- About Me
- Services Offered
- Portfolio Samples
- Client Testimonials
- Contact Information

## How to Use
- Clone this repo or download the .zip file
- Open `index.html` in your browser to view the site
- Customize or deploy to GitHub Pages, WordPress (HTML block), or hosting service

## Contact
- Email: estavilloabi@gmail.com
- Phone: 09380883728

Designed with 💖 by ChatGPT & Abigail Estavillo
